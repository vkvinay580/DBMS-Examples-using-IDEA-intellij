package vk.dbms;
import jdk.jfr.Category;
import java.sql.*;

public class LibDb
{

    public static void main(String[] args
    {
        System.out.println("Library DataBase");

//        createDB CDO= new createDB();
//        CDO.createNewDatabase("VKLibDB.db");

//        createTable CTO = new createTable();
//        CTO.createNewTable();

//        InsertRecords IRO = new InsertRecords();
//        IRO.insert(101, 30, "Lectures","J2SE",12,"Herbert Schildt");
//        IRO.insert(102, 35, "Lectures","SQL",21,"Shakespear");
//        IRO.insert(103, 25, "Lectures","LINUX",4,"JK Rowling");

//        selectDB SDO = new selectDB();
//        SDO.selectAll();

//        DropDB DDO = new DropDB();
//        DDO.DropDataBase();
    }

}
