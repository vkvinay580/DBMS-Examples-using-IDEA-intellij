package vk.dbms;

import java.sql.*;

public class selectDB {

    public static void selectAll() {
        String sql = "SELECT * FROM Books";
        Connection conn;
        try {
            Statement stmt;
            conn = DriverManager.getConnection("jdbc:sqlite:identifier.sqlite");
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            System.out.println("ISBN\t Price\t  Category\t\t Title\t\t Edition\t\t Author");
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("ISBN") + "\t\t" +
                        rs.getInt("Price") + "\t\t" +
                        rs.getString("Category") + "\t\t" +
                        rs.getString("Title") + "\t\t" +
                        rs.getInt("Edition") + "\t\t" +
                        rs.getString("Author"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
