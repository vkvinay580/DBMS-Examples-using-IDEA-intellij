package vk.dbms;

import java.sql.*;

public class insertDB {
    public static void insert(int ISBN, int Price, String Category, String Title, int Edition, String Author) {
        String sql = "INSERT INTO Books(ISBN, Price, Category, Title, Edition, Author) VALUES(?,?,?,?,?,?)";

        try {
//            Connection conn = connect();
            Connection conn;
            Statement stmt;
            conn = DriverManager.getConnection("jdbc:sqlite:identifier.sqlite");
            stmt = conn.createStatement();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, ISBN);
            pstmt.setInt(2, Price);
            pstmt.setString(3, Category);
            pstmt.setString(4, Title);
            pstmt.setInt(5, Edition);
            pstmt.setString(6, Author);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
