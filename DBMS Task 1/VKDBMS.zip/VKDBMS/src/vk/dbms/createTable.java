package vk.dbms;

import java.sql.*;

public class createTable {
    public static void createNewTable() {

        String sql = "CREATE TABLE IF NOT EXISTS ReservationRecords (\n"
                + " ReservationID integer PRIMARY KEY,\n"
                + " Reserver text NOT NULL,\n"
                + " BookISBN integer\n"
                + ");";

        try {
            Connection conn = DriverManager.getConnection("jdbc:sqlite:identifier.sqlite");
            Statement stmt = conn.createStatement();
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
