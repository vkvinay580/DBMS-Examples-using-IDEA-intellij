package vk.dbms;

import java.sql.*;


public class DropDB {


        public static void DropDataBase() {

            String sql = "DROP DATABASE VKLibDB.db;";

            try {
                Connection conn = DriverManager.getConnection("jdbc:sqlite:identifier.sqlite");
                Statement stmt = conn.createStatement();
                stmt.execute(sql);
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }

